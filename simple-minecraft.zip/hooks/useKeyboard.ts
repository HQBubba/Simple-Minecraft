
import { useState, useEffect } from 'react';

function actionByKey(key: string) {
  const keys: Record<string, string> = {
    KeyW: 'moveForward',
    KeyS: 'moveBackward',
    KeyA: 'moveLeft',
    KeyD: 'moveRight',
    Space: 'jump',
    KeyE: 'inventory',
    Digit1: 'slot1',
    Digit2: 'slot2',
    Digit3: 'slot3',
    Digit4: 'slot4',
    Digit5: 'slot5',
    Digit6: 'slot6',
    Digit7: 'slot7',
    Digit8: 'slot8',
    Digit9: 'slot9',
  };
  return keys[key];
}

export const useKeyboard = () => {
  const [actions, setActions] = useState({
    moveForward: false,
    moveBackward: false,
    moveLeft: false,
    moveRight: false,
    jump: false,
    inventory: false,
    slot1: false, slot2: false, slot3: false, slot4: false, slot5: false,
    slot6: false, slot7: false, slot8: false, slot9: false,
  });

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const action = actionByKey(event.code);
      if (action) {
        setActions((prev) => ({ ...prev, [action]: true }));
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      const action = actionByKey(event.code);
      if (action) {
        setActions((prev) => ({ ...prev, [action]: false }));
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return actions;
};
