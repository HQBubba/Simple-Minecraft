
import { GoogleGenAI, Type } from "@google/genai";
import { Block, BlockType } from '../types';

export const generateWorldLore = async (blocks: Block[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const blockCounts = blocks.reduce((acc, block) => {
    acc[block.type] = (acc[block.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const prompt = `Describe the lore of a Minecraft world containing: ${JSON.stringify(blockCounts)}. 2 sentences max.`;
  try {
    const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
    return response.text || "The Oracle is silent.";
  } catch (e) { return "Mists of the void."; }
};

export const generateBlueprint = async (description: string): Promise<{ pos: [number, number, number], type: BlockType }[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are a Minecraft Architect. Generate a set of relative block positions for a structure described as: "${description}".
    Use these block types ONLY: grass, dirt, log, glass, cobblestone, wood, leaves, stone, sand.
    Keep the structure small (under 40 blocks total).
    The coordinates (x,y,z) should be relative to a local origin (0,0,0).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              pos: { type: Type.ARRAY, items: { type: Type.NUMBER } },
              type: { type: Type.STRING }
            },
            required: ["pos", "type"]
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Architect Error:", error);
    return [];
  }
};
