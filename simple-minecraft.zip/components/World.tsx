
import React, { useMemo, useRef, useEffect, useCallback } from 'react';
import * as THREE from 'three';
import { BLOCKS } from '../constants';
import { BlockType, ChunkData } from '../types';
import { generatePixelTexture } from '../utils/textureGenerator';

interface WorldProps {
  chunks: Map<string, ChunkData>;
  onBlockInteract: (pos: [number, number, number], action: 'add' | 'remove', normal?: THREE.Vector3) => void;
}

const TEMP_OBJ = new THREE.Object3D();

export const World: React.FC<WorldProps> = ({ chunks, onBlockInteract }) => {
  const textures = useMemo(() => {
    const map = new Map<BlockType, THREE.Texture>();
    const loader = new THREE.TextureLoader();
    Object.keys(BLOCKS).forEach((key) => {
      const type = key as BlockType;
      const t = loader.load(generatePixelTexture(type));
      t.magFilter = THREE.NearestFilter;
      t.minFilter = THREE.NearestFilter;
      map.set(type, t);
    });
    return map;
  }, []);

  return (
    <group>
      {Array.from(chunks.entries()).map(([chunkKey, data]) => (
        <Chunk 
          key={chunkKey} 
          data={data} 
          textures={textures} 
          onInteract={onBlockInteract}
        />
      ))}
    </group>
  );
};

const Chunk: React.FC<{ 
  data: ChunkData; 
  textures: Map<BlockType, THREE.Texture>;
  onInteract: (pos: [number, number, number], action: 'add' | 'remove', normal?: THREE.Vector3) => void;
}> = ({ data, textures, onInteract }) => {
  const meshRefs = useRef<Map<BlockType, THREE.InstancedMesh>>(new Map());

  const counts = useMemo(() => {
    const c = new Map<BlockType, number>();
    data.forEach((type) => c.set(type, (c.get(type) || 0) + 1));
    return c;
  }, [data]);

  useEffect(() => {
    const instances = new Map<BlockType, number>();
    data.forEach((type, posStr) => {
      const [x, y, z] = posStr.split(',').map(Number);
      const mesh = meshRefs.current.get(type);
      if (mesh) {
        const index = instances.get(type) || 0;
        TEMP_OBJ.position.set(x, y, z);
        TEMP_OBJ.updateMatrix();
        mesh.setMatrixAt(index, TEMP_OBJ.matrix);
        instances.set(type, index + 1);
      }
    });

    meshRefs.current.forEach((mesh) => {
      if (mesh && mesh.instanceMatrix) {
        mesh.instanceMatrix.needsUpdate = true;
        // Optimization and safety: Only compute if mesh and its geometry are ready
        if (mesh.geometry) {
           mesh.computeBoundingSphere();
        }
      }
    });
  }, [data]);

  const handlePointerDown = (e: any) => {
    e.stopPropagation();
    const mesh = e.object as THREE.InstancedMesh;
    const instanceId = e.instanceId;
    if (instanceId === undefined) return;

    const matrix = new THREE.Matrix4();
    mesh.getMatrixAt(instanceId, matrix);
    const pos = new THREE.Vector3().setFromMatrixPosition(matrix);
    
    const isRightClick = e.button === 2;
    if (isRightClick) {
      onInteract([pos.x, pos.y, pos.z], 'add', e.face.normal);
    } else {
      onInteract([pos.x, pos.y, pos.z], 'remove');
    }
  };

  return (
    <group>
      {Array.from(counts.entries()).map(([type, count]) => (
        <instancedMesh
          key={type}
          // Fix: React 19 expects the ref callback to return a cleanup function or nothing.
          // Returning meshRefs.current.set(...) returns the Map object, which triggers "refCleanup is not a function".
          ref={(el) => {
            if (el) {
              meshRefs.current.set(type, el);
            } else {
              meshRefs.current.delete(type);
            }
          }}
          args={[null as any, null as any, count]}
          onPointerDown={handlePointerDown}
        >
          <boxGeometry />
          <meshStandardMaterial 
            map={textures.get(type)} 
            transparent={BLOCKS[type].transparent}
            alphaTest={0.5}
          />
        </instancedMesh>
      ))}
    </group>
  );
};
