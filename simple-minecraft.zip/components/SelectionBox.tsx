import React, { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

export const SelectionBox: React.FC = () => {
  const meshRef = useRef<THREE.LineSegments>(null);
  const { camera, raycaster, scene } = useThree();

  useFrame(() => {
    if (!meshRef.current) return;
    // Fix: raycaster.setFromCamera expects a THREE.Vector2, not a plain object.
    raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
    const intersects = raycaster.intersectObjects(scene.children, true);
    
    // Find the first block (instanced meshes are tricky, usually world is first)
    const block = intersects.find(i => i.object.type === 'InstancedMesh');
    
    if (block && block.distance < 5) {
      const instanceId = block.instanceId!;
      const mesh = block.object as THREE.InstancedMesh;
      const matrix = new THREE.Matrix4();
      mesh.getMatrixAt(instanceId, matrix);
      const position = new THREE.Vector3();
      position.setFromMatrixPosition(matrix);
      
      meshRef.current.position.copy(position);
      meshRef.current.visible = true;
    } else {
      meshRef.current.visible = false;
    }
  });

  return (
    <lineSegments ref={meshRef} visible={false}>
      <edgesGeometry args={[new THREE.BoxGeometry(1.01, 1.01, 1.01)]} />
      <lineBasicMaterial color="black" linewidth={2} />
    </lineSegments>
  );
};