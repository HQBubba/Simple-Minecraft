
import React from 'react';
import { useThree } from '@react-three/fiber';

interface GroundProps {
  addBlock: (x: number, y: number, z: number) => void;
}

export const Ground: React.FC<GroundProps> = ({ addBlock }) => {
  return (
    <mesh
      rotation={[-Math.PI / 2, 0, 0]}
      position={[0, -0.5, 0]}
      onClick={(e) => {
        e.stopPropagation();
        // Fix: Explicitly access x and z from e.point to avoid 'unknown' type errors from Object.values
        const x = Math.round(e.point.x);
        const z = Math.round(e.point.z);
        addBlock(x, 0, z);
      }}
    >
      <planeGeometry args={[100, 100]} />
      <meshStandardMaterial color="#2d4d12" />
    </mesh>
  );
};
