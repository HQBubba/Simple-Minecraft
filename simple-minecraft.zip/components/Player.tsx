
import React, { useRef } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { Vector3 } from 'three';
import { useKeyboard } from '../hooks/useKeyboard';
import { PointerLockControls } from '@react-three/drei';
import { GameState, ChunkData } from '../types';

interface PlayerProps {
  chunks: Map<string, ChunkData>;
  gameState: GameState;
  onDamage: (amount: number) => void;
  playerPosRef: React.MutableRefObject<Vector3>;
}

export const Player: React.FC<PlayerProps> = ({ chunks, gameState, onDamage, playerPosRef }) => {
  const { camera } = useThree();
  const { moveForward, moveBackward, moveLeft, moveRight, jump } = useKeyboard();
  const velocity = useRef(new Vector3(0, 0, 0));
  const pos = useRef(new Vector3(0, 30, 0));

  const checkCollision = (p: Vector3) => {
    // Player bounds: height 1.8, width 0.6 (radius 0.3)
    const playerRadius = 0.3;
    const playerHeight = 1.8;
    const padding = 0.05;

    // Check bottom, middle, and top levels
    const levels = [padding, 0.9, playerHeight - padding];
    const horizontalOffsets = [
      [0, 0],
      [playerRadius, 0], [-playerRadius, 0],
      [0, playerRadius], [0, -playerRadius]
    ];

    for (const yOff of levels) {
      for (const [xOff, zOff] of horizontalOffsets) {
        const bx = Math.round(p.x + xOff);
        const by = Math.round(p.y - 1.5 + yOff);
        const bz = Math.round(p.z + zOff);
        
        const cx = Math.floor(bx / 16);
        const cz = Math.floor(bz / 16);
        const chunk = chunks.get(`${cx},${cz}`);
        if (chunk && chunk.has(`${bx},${by},${bz}`)) return true;
      }
    }
    return p.y < -5; // World void
  };

  useFrame((state, delta) => {
    if (gameState !== GameState.PLAYING) return;

    const speed = 4.5;
    const direction = new Vector3();
    const frontVector = new Vector3(0, 0, Number(moveBackward) - Number(moveForward));
    const sideVector = new Vector3(Number(moveLeft) - Number(moveRight), 0, 0);

    direction.subVectors(frontVector, sideVector).normalize().multiplyScalar(speed).applyEuler(camera.rotation);

    // Gravity
    velocity.current.y -= 28 * delta;
    
    // Horizontal Movement with collision
    const nextX = pos.current.clone();
    nextX.x += direction.x * delta;
    if (!checkCollision(nextX)) pos.current.x = nextX.x;

    const nextZ = pos.current.clone();
    nextZ.z += direction.z * delta;
    if (!checkCollision(nextZ)) pos.current.z = nextZ.z;

    // Vertical Movement & Collision
    const nextY = pos.current.clone();
    nextY.y += velocity.current.y * delta;
    if (checkCollision(nextY)) {
      if (velocity.current.y < -15) onDamage(5); // Fall damage
      velocity.current.y = 0;
      if (jump) velocity.current.y = 9;
    } else {
      pos.current.y = nextY.y;
    }

    camera.position.copy(pos.current);
    playerPosRef.current.copy(pos.current);
    
    // Camera Bobbing
    if (moveForward || moveBackward || moveLeft || moveRight) {
        camera.position.y += Math.sin(state.clock.elapsedTime * 10) * 0.03;
    }
  });

  return gameState === GameState.PLAYING ? <PointerLockControls /> : null;
};
