
import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Vector3, Mesh } from 'three';
import { EntityType } from '../types';

interface MobProps {
  type: EntityType;
  position: [number, number, number];
  playerPosition: Vector3;
  onAttack: () => void;
}

export const Mob: React.FC<MobProps> = ({ type, position, playerPosition, onAttack }) => {
  const mesh = useRef<Mesh>(null);
  const pos = useRef(new Vector3(...position));
  const lastAttack = useRef(0);

  const mobData = useMemo(() => {
    switch(type) {
      case 'zombie': return { color: '#3b5d3a', speed: 2.2, height: 1.8, hostile: true };
      case 'creeper': return { color: '#16a34a', speed: 2.5, height: 1.6, hostile: true };
      case 'enderman': return { color: '#111827', speed: 3.5, height: 2.8, hostile: true };
      case 'pig': return { color: '#f9a8d4', speed: 1.5, height: 0.8, hostile: false };
      default: return { color: '#ffffff', speed: 1, height: 1, hostile: false };
    }
  }, [type]);

  useFrame((state, delta) => {
    if (!mesh.current) return;

    const dir = new Vector3().subVectors(playerPosition, pos.current);
    dir.y = 0;
    const dist = dir.length();

    if (mobData.hostile && dist < 12 && dist > 1.0) {
      dir.normalize().multiplyScalar(mobData.speed * delta);
      pos.current.add(dir);
      mesh.current.position.copy(pos.current);
      mesh.current.lookAt(playerPosition.x, pos.current.y, playerPosition.z);
    } else if (!mobData.hostile) {
      // Random wandering logic could go here
    }

    if (mobData.hostile && dist <= 1.5 && Date.now() - lastAttack.current > 1500) {
      onAttack();
      lastAttack.current = Date.now();
    }
    
    mesh.current.position.y = pos.current.y + Math.sin(state.clock.elapsedTime * 3) * 0.05;
  });

  return (
    <group>
      <mesh ref={mesh} position={position}>
        <boxGeometry args={[0.6, mobData.height, 0.6]} />
        <meshStandardMaterial color={mobData.color} />
        {type === 'enderman' && <pointLight intensity={0.5} color="#c084fc" distance={2} />}
      </mesh>
    </group>
  );
};
