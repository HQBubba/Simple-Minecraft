
import React, { useMemo, useState } from 'react';
import * as THREE from 'three';
import { BlockType } from '../types';
import { BLOCKS } from '../constants';
import { generatePixelTexture } from '../utils/textureGenerator';

interface CubeProps {
  position: [number, number, number];
  type: BlockType;
  addBlock: (x: number, y: number, z: number) => void;
  removeBlock: (x: number, y: number, z: number) => void;
}

export const Cube: React.FC<CubeProps> = ({ position, type, addBlock, removeBlock }) => {
  const [hover, setHover] = useState<number | null>(null);
  const textureUrl = useMemo(() => generatePixelTexture(type), [type]);
  const texture = useMemo(() => {
    const loader = new THREE.TextureLoader();
    const t = loader.load(textureUrl);
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    return t;
  }, [textureUrl]);

  return (
    <mesh
      position={position}
      onPointerMove={(e) => {
        e.stopPropagation();
        setHover(Math.floor(e.faceIndex! / 2));
      }}
      onPointerOut={() => setHover(null)}
      onClick={(e) => {
        e.stopPropagation();
        if (e.button === 2 || e.shiftKey) {
          removeBlock(...position);
          return;
        }

        const clickedFace = Math.floor(e.faceIndex! / 2);
        const [px, py, pz] = position;
        if (clickedFace === 0) addBlock(px + 1, py, pz);
        else if (clickedFace === 1) addBlock(px - 1, py, pz);
        else if (clickedFace === 2) addBlock(px, py + 1, pz);
        else if (clickedFace === 3) addBlock(px, py - 1, pz);
        else if (clickedFace === 4) addBlock(px, py, pz + 1);
        else if (clickedFace === 5) addBlock(px, py, pz - 1);
      }}
    >
      <boxGeometry />
      <meshStandardMaterial
        map={texture}
        color={hover !== null ? '#cccccc' : 'white'}
        transparent={BLOCKS[type].transparent}
        opacity={type === 'glass' ? 0.4 : (type === 'leaves' ? 0.8 : 1)}
      />
    </mesh>
  );
};
