
import { BLOCKS } from '../constants';
import { BlockType } from '../types';

export const generatePixelTexture = (type: BlockType) => {
  const canvas = document.createElement('canvas');
  canvas.width = 16;
  canvas.height = 16;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const { color, altColor } = BLOCKS[type];

  // Base fill
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, 16, 16);

  // Noise/Texture
  for (let x = 0; x < 16; x++) {
    for (let y = 0; y < 16; y++) {
      if (Math.random() > 0.7) {
        ctx.fillStyle = Math.random() > 0.5 ? altColor : color;
        ctx.globalAlpha = 0.2;
        ctx.fillRect(x, y, 1, 1);
        ctx.globalAlpha = 1.0;
      }
    }
  }

  // Border logic for specific blocks
  if (type === 'cobblestone' || type === 'wood' || type === 'log') {
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.strokeRect(0, 0, 16, 16);
  }

  if (type === 'glass') {
    ctx.strokeStyle = 'white';
    ctx.beginPath();
    ctx.moveTo(2, 2); ctx.lineTo(6, 6);
    ctx.moveTo(8, 2); ctx.lineTo(10, 4);
    ctx.stroke();
  }

  return canvas.toDataURL();
};
