
export type BlockType = 
  | 'grass' | 'dirt' | 'log' | 'glass' | 'cobblestone' | 'wood' | 'leaves' | 'stone' | 'sand' | 'bedrock' 
  | 'coal_ore' | 'iron_ore' | 'gold_ore' | 'diamond_ore' | 'emerald_ore'
  | 'obsidian' | 'netherrack' | 'soul_sand' | 'glowstone' | 'magma'
  | 'end_stone' | 'purpur' | 'portal_nether' | 'portal_end'
  | 'apple' | 'raw_beef' | 'cooked_beef' | 'iron_sword' | 'diamond_pickaxe';

export type Dimension = 'overworld' | 'nether' | 'end';

export interface Block {
  type: BlockType;
}

export type ChunkData = Map<string, BlockType>;

export interface InventoryItem {
  type: BlockType;
  count: number;
}

export enum GameState {
  PLAYING = 'PLAYING',
  INVENTORY = 'INVENTORY',
  DEAD = 'DEAD'
}

export type EntityType = 'zombie' | 'creeper' | 'enderman' | 'pig' | 'cow';

export interface Entity {
  id: string;
  type: EntityType;
  position: [number, number, number];
  health: number;
}
